package Interfaces;
import java.util.List;

import org.lwjgl.util.Rectangle;//?

import Constants.SoundEffects;
import MarioLevel.HUD;

public interface IBlock
    {
        void Draw();
        void Update();
        Rectangle GetRectangle();
        void Hit(List<IItem> items, boolean marioIsBig, HUD hud, SoundEffects sound);
    }
