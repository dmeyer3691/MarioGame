package Interfaces;
import Mario.Mario;
import MarioLevel.MainGame;

    public interface IController
    {
        void Update(MainGame game, Mario mario);
    }

