package Interfaces;
import java.util.List;

import org.lwjgl.util.Rectangle;//?

    public interface IEnemy
    {

        void Draw();
        void Fall(int f);
        void Reverse(int w);
        void Update(List<IBlock> blocks, List<IEnemy> enemies);
        Rectangle GetRectangle();
    }
