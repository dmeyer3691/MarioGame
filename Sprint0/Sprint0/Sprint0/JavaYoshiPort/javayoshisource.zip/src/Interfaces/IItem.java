package Interfaces;

import java.util.List;

import org.lwjgl.util.Rectangle;

    public interface IItem
    {
        void Draw();
        void Reverse();
        void Update(List<IBlock> blocks);
        Rectangle GetRectangle();
        String GetItemName();
        void moveYPosition(int offset);
        boolean DestroyItem();
    }