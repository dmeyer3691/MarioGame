package Interfaces;
    public interface ICommand
    {
        void Execute();
    }