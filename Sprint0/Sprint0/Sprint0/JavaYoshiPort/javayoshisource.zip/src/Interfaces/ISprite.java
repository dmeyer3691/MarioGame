package Interfaces;
    public interface ISprite
    {
    	public enum SpriteEffects{
    		NONE, HORIZONTAL_FLIP
    	}
        void Update();
        void Draw(int x, int y, SpriteEffects facing);
        int GetWidth();
        int GetHeight();
    }
