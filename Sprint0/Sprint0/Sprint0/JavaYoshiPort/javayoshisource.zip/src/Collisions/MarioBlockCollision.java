package Collisions;

import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Constants.Constants;
import Constants.FourTuple;
import Constants.SoundEffects;
import Interfaces.*;
import Mario.Mario;
import MarioLevel.HUD;

    public class MarioBlockCollision
    {

        private Mario myMario;

        public MarioBlockCollision(Mario mario)
        {
            myMario = mario;
        }

        public FourTuple<Integer, Integer, Boolean, Boolean> BlockCollisionTest(SoundEffects sound, HUD hud, List<IBlock> blocks, int x, int y, List<IItem> items, Camera c)
        {
            Rectangle marioRectangle = myMario.GetRectangle();
            Rectangle blockRectangle;
            Rectangle intersectionRectangle = new Rectangle();
            boolean hitGround = false;
            boolean hitCeiling = false;
            FourTuple<Integer, Integer, Boolean, Boolean> result;
            for (IBlock block : blocks)
            {
                blockRectangle = block.GetRectangle();
                intersectionRectangle = marioRectangle.intersection(blockRectangle, intersectionRectangle);
                if (!intersectionRectangle.isEmpty())
                {
                    if ((intersectionRectangle.getWidth() >= intersectionRectangle.getHeight()))
                    {
                        if (marioRectangle.getY() > blockRectangle.getY())
                        {
                            block.Hit(items, myMario.IsLarge(), hud, sound);
                            hitCeiling = true;
                            y += (intersectionRectangle.getHeight());
                            marioRectangle.setY(marioRectangle.getY() + intersectionRectangle.getHeight());
                        }
                        else
                        {
                            hitGround = true;
                            if (block instanceof Blocks.VerticalWarpPipe)
                            {
                                if (myMario.IsCrouching())
                                {
                                    c.SetXPos(Constants.verticalWarp.a-Constants.tileLength);
                                    x = Constants.verticalWarp.a;
                                    y = Constants.verticalWarp.b;
                                    break;
                                }
                            }
                            y -= (intersectionRectangle.getHeight());
                            marioRectangle.setY(marioRectangle.getY() - intersectionRectangle.getHeight());
                        }
                    }
                    else
                    {
                        if (marioRectangle.getX() > blockRectangle.getX())
                        {
                            x += (intersectionRectangle.getWidth());
                            marioRectangle.setX(marioRectangle.getX() + intersectionRectangle.getWidth());
                        }
                        else
                        {
                            x -= (intersectionRectangle.getWidth());
                            marioRectangle.setX(marioRectangle.getX() - intersectionRectangle.getWidth());
                            if (block instanceof Blocks.HorizontalWarpPipe)
                            {
                                c.SetXPos(Constants.horizontalWarp.a-Constants.tileLength);
                                x = Constants.horizontalWarp.a;
                                y = Constants.horizontalWarp.b;                                
                                break;
                            }
                        }
                    }
                }
            }
            result = new FourTuple<Integer, Integer, Boolean, Boolean>(x, y, hitCeiling, hitGround);
            return result;
        }

    }