package Collisions;
import java.util.List;

import org.lwjgl.util.Rectangle;
import Interfaces.*;

    public class ItemAllCollision
    {

        private IItem myItem;

        public ItemAllCollision(IItem item)
        {
            myItem = item;
        }

        public void ItemCollisionTest(List<IBlock> blocks)
        {
            Rectangle myRectangle = myItem.GetRectangle();
            Rectangle blockRectangle;
            Rectangle intersectionRectangle = new Rectangle();

            for (IBlock block : blocks)
            {

                blockRectangle = block.GetRectangle();
                intersectionRectangle = myRectangle.intersection(blockRectangle, intersectionRectangle);

                if (!intersectionRectangle.isEmpty())
                {
                    if (intersectionRectangle.getWidth() >= intersectionRectangle.getHeight())
                    {
                        myItem.moveYPosition(-intersectionRectangle.getHeight());
                        return;
                    }

                    else if (myRectangle.getX() < blockRectangle.getX())
                    {
                        myItem.Reverse();
                    }
                    else if (myRectangle.getX() > blockRectangle.getX())
                    {
                        myItem.Reverse();
                    }
                }
            }
        }
    }
