package Collisions;

import java.util.LinkedList;
import java.util.List;
import org.lwjgl.util.Rectangle;

import Constants.SoundEffects;
import Constants.Tuple;
import Interfaces.*;
import Mario.Mario;
import MarioLevel.HUD;

    public class MarioEnemyCollision
    {

        private Mario myMario;

        public MarioEnemyCollision(Mario mario)
        {
            myMario = mario;
        }

        public Tuple<Integer, Boolean> EnemyCollisionTest(Mario mario, HUD hud, List<IEnemy> enemies, int x, SoundEffects sound)
        {
            Rectangle marioRectangle = myMario.GetRectangle();
            Rectangle enemyRectangle;
            boolean enemyKilled = false;
            boolean invincible = myMario.Invincible();
            int xpos = x;
            Rectangle intersectionRectangle = new Rectangle();
            LinkedList<IEnemy> doomedEnemies = new LinkedList<IEnemy>();

            for (IEnemy enemy : enemies)
            {

                enemyRectangle = enemy.GetRectangle();
                intersectionRectangle = marioRectangle.intersection(enemyRectangle, intersectionRectangle);

                if (!intersectionRectangle.isEmpty())
                {
                    

                    if (intersectionRectangle.getWidth() >= intersectionRectangle.getHeight())
                    {
                        sound.Bump();
                        doomedEnemies.add(enemy);
                        hud.enemyKill(mario);
                        enemyKilled = true;
                    }
                    else if (invincible)
                    {
                        doomedEnemies.add(enemy);
                    }
                    else
                    {
                        myMario.Hit();
                        if (marioRectangle.getX() < enemyRectangle.getX())
                        {
                            xpos = xpos - intersectionRectangle.getWidth();
                        }
                        else
                        {
                            xpos = xpos + intersectionRectangle.getWidth();

                        }
                        if (myMario.IsDead())
                        {
                            hud.lifeLost();
                        }
                    }

                }
            }
            
            while (doomedEnemies.size() > 0)
            {
                IEnemy enemie = doomedEnemies.remove();
                enemies.remove(enemie);
            }

            return new Tuple<Integer,Boolean>(xpos, enemyKilled);
        }
    }