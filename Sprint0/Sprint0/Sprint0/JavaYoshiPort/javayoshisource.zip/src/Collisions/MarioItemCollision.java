package Collisions;

import java.util.LinkedList;
import java.util.List;

import org.lwjgl.util.Rectangle;

import Interfaces.*;
import Mario.Mario;
import MarioLevel.HUD;

import Constants.*;

    public class MarioItemCollision
    {

        private Mario myMario;

        public MarioItemCollision(Mario mario)
        {
            myMario = mario;
        }

        public void ItemCollisionTest(SoundEffects sound, HUD hud, List<IItem> items)
        {
            Rectangle marioRectangle = myMario.GetRectangle();
            Rectangle itemRectangle;
            Rectangle intersectionRectangle = new Rectangle();
            LinkedList<IItem> doomedItems = new LinkedList<IItem>();
            for (IItem item : items)
            {
                itemRectangle = item.GetRectangle();
                intersectionRectangle = marioRectangle.intersection(itemRectangle, intersectionRectangle);
                if (!intersectionRectangle.isEmpty())
                {
                    // todo
                    switch (item.GetItemName())
                    {
                        case "Coin":
                            //myMario.Coin();
                            hud.addCoin();
                            hud.increaseScore(Constants.coinValue);
                            break;
                        case "Mushroom":
                            sound.Powerup();
                            myMario.Mushroom();
                            hud.increaseScore(Constants.mushroomValue);
                            break;
                        case "Fireflower":
                            sound.Powerup();
                            myMario.Fireflower();
                            hud.increaseScore(Constants.fireflowerValue);
                            break;
                        case "Oneup":
                            sound.OneUp();
                            hud.extraLife();
                            hud.increaseScore(Constants.oneUpValue);
                            break;
                        case "Star":
                            sound.Powerup();
                            myMario.Star();
                            hud.increaseScore(Constants.starValue);
                            break;
                        default:
                            // nothing
                            break;
                    }
                    doomedItems.add(item);


                }
            }
            while (doomedItems.size() > 0)
            {
                IItem item = doomedItems.remove();
                items.remove(item);


            }
        }

    }
