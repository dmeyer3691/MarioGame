package Collisions;
import java.util.List;
import org.lwjgl.util.Rectangle;
import Interfaces.*;

    public class EnemyAllCollision
    {
        
        private IEnemy myEnemy;

        public EnemyAllCollision(IEnemy enemy)
        {
            myEnemy = enemy;
        }

        public void BlockCollisionTest(List<IBlock> blocks)
        {
            Rectangle myRectangle = myEnemy.GetRectangle();
            Rectangle blockRectangle;
            Rectangle intersectionRectangle = new Rectangle();

            for (IBlock block : blocks)
            {

                blockRectangle = block.GetRectangle();
                intersectionRectangle = myRectangle.intersection(blockRectangle, intersectionRectangle);                

                if (!intersectionRectangle.isEmpty())
                {
                    if (intersectionRectangle.getWidth() >= intersectionRectangle.getHeight())
                    {
                        if (myRectangle.getY() <= blockRectangle.getY())
                        {
                            myEnemy.Fall(intersectionRectangle.getHeight());
                        }
                    }

                    else if (myRectangle.getX() <= blockRectangle.getX())
                    {
                        if (myRectangle.getY() >= blockRectangle.getY())
                        {
                            myEnemy.Reverse(intersectionRectangle.getWidth());
                        }
                    }
                    else if (myRectangle.getX() >= blockRectangle.getX())
                    {
                        if (myRectangle.getY() >= blockRectangle.getY())
                        {
                            myEnemy.Reverse(intersectionRectangle.getWidth());
                        }
                    }
                }
                

            }
        }

        public void EnemyCollisionTest(List<IEnemy> enemies)
        {
            Rectangle myRectangle = myEnemy.GetRectangle();
            Rectangle enemyRectangle;
            Rectangle intersectionRectangle = new Rectangle();

            for (IEnemy enemy : enemies)
            {

                enemyRectangle = enemy.GetRectangle();
                intersectionRectangle = myRectangle.intersection(enemyRectangle, intersectionRectangle);

                if (!intersectionRectangle.isEmpty())
                {
                    if (myRectangle.getX() < enemyRectangle.getX())
                    {
                        myEnemy.Reverse(intersectionRectangle.getWidth() / 2);
                        enemy.Reverse(intersectionRectangle.getWidth() / 2);
                    }
                    else if (myRectangle.getX() > enemyRectangle.getX())
                    {
                        myEnemy.Reverse(intersectionRectangle.getWidth() / 2);
                        enemy.Reverse(intersectionRectangle.getWidth() / 2);
                    }
                }

            }
            
        }
    }
