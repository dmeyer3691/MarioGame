package Items;

import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Interfaces.*;


    public class Coin implements IItem
    {

        private ISprite CoinSprite = new Sprites.CoinSprite();
        private int xPosition;
        private int yPosition;
        private int duration;
        private boolean destroy;
        Camera camera;
        public Coin(int x, int y, Camera cam)
        {
            destroy = false;
            duration = 0;
            camera = cam;
            xPosition = x;
            yPosition = y;
        }
        
        public void Reverse()
        {
        }

        public void Draw()
        {
            camera.Draw(CoinSprite, xPosition, yPosition);
        }

        public String GetItemName()
        {
            return "Coin";
        }

        public void Update(List<IBlock> blocks)
        {
            if (duration <= 6)
            {
                yPosition = yPosition - 5;
                duration++;
                CoinSprite.Update();
            }
            else if (duration <= 12)
            {
                yPosition = yPosition + 5;
                duration++;
                CoinSprite.Update();
            }
            else
            {
                destroy = true;
            }


            
        }
        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, CoinSprite.GetWidth(), CoinSprite.GetHeight());
        }
        public void moveYPosition(int offset)
        {
            yPosition += offset;
        }

        public boolean DestroyItem() { return destroy; }

    }
