package Items;

import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Interfaces.*;

    public class Star implements IItem
    {
        private Collisions.ItemAllCollision itemAllCollisions;
        private boolean movingRight;

        private ISprite StarSprite = new Sprites.StarSprite();
        private int xPosition;
        private int yPosition;
        private Camera camera;

        public Star(int x, int y, Camera cam)
        {
            itemAllCollisions = new Collisions.ItemAllCollision(this);
            movingRight = true;
            camera = cam;
            xPosition = x;
            yPosition = y;
        }


        public void Reverse()
        {
            if (movingRight)
            {
                movingRight = false;
            }
            else
            {
                movingRight = true;
            }
        }

        public void Draw()
        {
            camera.Draw(StarSprite, xPosition, yPosition);
        }

        public String GetItemName()
        {
            return "Star";
        }

        public void Update(List<IBlock> blocks)
        {

            yPosition++;
            itemAllCollisions.ItemCollisionTest(blocks);

            if (movingRight)
            {
                xPosition++;
            }
            else
            {
                xPosition--;
            }

            StarSprite.Update();
        }
        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, StarSprite.GetWidth(), StarSprite.GetHeight());
        }
        public void moveYPosition(int offset)
        {
            yPosition += offset;
        }
        public boolean DestroyItem() { return false; }
    }
