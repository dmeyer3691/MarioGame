package Items;

import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Interfaces.*;


    public class Fireflower implements IItem
    {
        private ISprite FireflowerSprite = new Sprites.FireflowerSprite();
        private int xPosition;
        private int yPosition;
        private Camera camera;

        public Fireflower(int x, int y, Camera cam)
        {
            camera = cam;
            xPosition = x;
            yPosition = y;
        }

        public void Reverse()
        {

        }

        public void Draw()
        {
            camera.Draw(FireflowerSprite, xPosition, yPosition);
        }

        public String GetItemName()
        {
            return "Fireflower";
        }

        public void Update(List<IBlock> blocks)
        {

        }
        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, FireflowerSprite.GetWidth(), FireflowerSprite.GetHeight());
        }
        public void moveYPosition(int offset)
        {
            yPosition += offset;
        }
        public boolean DestroyItem() { return false; }
    }
