package Enemies;
import java.util.List;
import org.lwjgl.util.Rectangle;
import Interfaces.*;
import Camera.*;
import Collisions.EnemyAllCollision;
import Constants.Constants;


    public class Goomba implements IEnemy
    {

        private EnemyAllCollision enemyAllCollisions;
        boolean movingRight;
        boolean found;

        private static ISprite GoombaSprite = new Sprites.GoombaSprite();
        private int xPosition;
        private int yPosition;
        Camera camera;

        public Goomba(int x, int y, Camera cam)
        {
            enemyAllCollisions = new EnemyAllCollision(this);
            found = false;
            camera = cam;
            xPosition = x;
            yPosition = y;
        }

        public void Draw()
        {
            camera.Draw(GoombaSprite, xPosition, yPosition);
        }
        public void Fall(int f)
        {
            yPosition = yPosition - f;
        }

        public void Reverse(int w)
        {
            if (movingRight)
            {
                xPosition = xPosition - w;
                movingRight = false;
            }
            else
            {
                xPosition = xPosition + w;
                movingRight = true;
            }
        }

        public void Update(List<IBlock> blocks, List<IEnemy> enemies)
        {
            int cam = camera.CameraPos();
            if ((cam + Constants.enemyWakeDistance) > xPosition)
            {
                found = true;
            }
            if (found)
            {
                yPosition++;
                enemyAllCollisions.BlockCollisionTest(blocks);
                enemyAllCollisions.EnemyCollisionTest(enemies);

                if (movingRight)
                {
                    xPosition++;
                }
                else
                {
                    xPosition--;
                }

                GoombaSprite.Update();
            }
        }

        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, GoombaSprite.GetWidth(), GoombaSprite.GetHeight());
        }
    }
