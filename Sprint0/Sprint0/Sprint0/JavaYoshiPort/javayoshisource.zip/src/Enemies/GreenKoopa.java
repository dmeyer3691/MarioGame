package Enemies;
import java.util.List;

import org.lwjgl.util.Rectangle;
import Interfaces.*;
import Camera.*;
import Collisions.EnemyAllCollision;
import Constants.Constants;

    public class GreenKoopa implements IEnemy
    {
        private EnemyAllCollision enemyAllCollisions;
        boolean movingRight;
        boolean found;
        private ISprite.SpriteEffects facing;

        private static ISprite KoopaSprite = new Sprites.GreenTurtleSprite();
        private int xPosition;
        private int yPosition;
        private Camera camera;
        public GreenKoopa(int x, int y, Camera cam)
        {
            enemyAllCollisions = new EnemyAllCollision(this);
            facing = ISprite.SpriteEffects.NONE;
            found = false;
            camera = cam;
            xPosition = x;
            yPosition = y;
        }
        
        public void Draw()
        {
            camera.Draw(KoopaSprite, xPosition, yPosition, facing);
        }
        public void Fall(int f)
        {
            yPosition = yPosition - f;
        }

        public void Reverse(int w)
        {
            
            if (movingRight)
            {
                facing = ISprite.SpriteEffects.NONE;
                xPosition = xPosition - w;
                movingRight = false;
            }
            else
            { 
                facing = ISprite.SpriteEffects.HORIZONTAL_FLIP;
                xPosition = xPosition + w;
                movingRight = true;
            }
        }

        public void Update(List<IBlock> blocks, List<IEnemy> enemies)
        {
            int cam = camera.CameraPos();
            if ((cam + Constants.enemyWakeDistance) > xPosition)
            {
                found = true;
            }
            if (found)
            {
                yPosition++;
                enemyAllCollisions.BlockCollisionTest(blocks);
                enemyAllCollisions.EnemyCollisionTest(enemies);

                if (movingRight)
                {
                    xPosition++;
                }
                else
                {
                    xPosition--;
                }

                KoopaSprite.Update();
            }
        }
        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, KoopaSprite.GetWidth(), KoopaSprite.GetHeight());
        }
    }
