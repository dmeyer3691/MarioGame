package Blocks;

import java.util.List;

import org.lwjgl.util.Rectangle;
import Constants.*;
import Camera.Camera;
import Interfaces.*;
import MarioLevel.HUD;

public class GreenBrick implements IBlock
    {
        private ISprite GreenBrickSprite = new Sprites.BrickSprite();//todo: make it green
        private int xPosition;
        private int yPosition;
        Camera camera;

        public GreenBrick(int x, int y, Camera cam)
        {
            camera = cam;
            xPosition = x;
            yPosition = y;
        }


        public void Draw()
        {
            if(GreenBrickSprite != null) camera.Draw(GreenBrickSprite, xPosition, yPosition);
        }

        public void Update()
        {
        }

        public Rectangle GetRectangle()
        {
            if (GreenBrickSprite == null) return new Rectangle(xPosition, yPosition, 0, 0);
            return new Rectangle(xPosition, yPosition, GreenBrickSprite.GetWidth(), GreenBrickSprite.GetHeight());
        }

        public void Hit(List<IItem> items, boolean marioIsBig, HUD hud, SoundEffects sound) {
            if (marioIsBig)
            {
                sound.BreakBlock();
                hud.increaseScore(Constants.brokenBrickValue);
                GreenBrickSprite = null;
            }
        }


    }