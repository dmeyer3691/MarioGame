package Blocks;

import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Constants.SoundEffects;
import Interfaces.*;
import MarioLevel.HUD;

public class Flagpole implements IBlock {
        private static ISprite CastleSprite = new Sprites.FlagpoleSprite();
        private int xPosition;
        private int yPosition;
        Camera camera;

        public Flagpole(int x, int y, Camera cam)
        {
            camera = cam;
            xPosition = x;
            yPosition = y;
        }


        public void Draw()
        {
            camera.Draw(CastleSprite, xPosition, yPosition);
        }

        public void Update()
        {
        }

        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, 0, 0);//no collisions with flagpoles
        }

        public void Hit(List<IItem> items, boolean marioIsBig, HUD hud, SoundEffects sound) { }


    }