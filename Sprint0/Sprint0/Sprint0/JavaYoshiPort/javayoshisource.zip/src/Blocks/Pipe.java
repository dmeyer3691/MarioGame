package Blocks;
import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Constants.SoundEffects;
import Interfaces.*;
import MarioLevel.HUD;

    public class Pipe implements IBlock
    {
        private static ISprite PipeSprite = new Sprites.PipeSprite();
        private int xPosition;
        private int yPosition;
        Camera camera;

        public Pipe(int x, int y, Camera cam)
        {
            camera = cam;
            xPosition = x;
            yPosition = y;
        }


        public void Draw()
        {
            camera.Draw(PipeSprite, xPosition, yPosition);
        }

        public void Update()
        {
        }

        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, PipeSprite.GetWidth(), PipeSprite.GetHeight());
        }

        public void Hit(List<IItem> items, boolean marioIsBig, HUD hud, SoundEffects sound) { }



    }