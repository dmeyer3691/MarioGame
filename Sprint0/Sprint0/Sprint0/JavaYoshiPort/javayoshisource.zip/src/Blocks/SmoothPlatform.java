package Blocks;
import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Constants.SoundEffects;
import Interfaces.*;
import MarioLevel.HUD;

    public class SmoothPlatform implements IBlock
    {
        private static ISprite SmoothPlatformSprite = new Sprites.SmoothPlatformSprite();
        private int xPosition;
        private int yPosition;
        Camera camera;

        public SmoothPlatform(int x, int y, Camera cam)
        {
            camera = cam;
            xPosition = x;
            yPosition = y;
        }


        public void Draw()
        {
            camera.Draw(SmoothPlatformSprite, xPosition, yPosition);
        }

        public void Update()
        {
        }

        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, SmoothPlatformSprite.GetWidth(), SmoothPlatformSprite.GetHeight());
        }

        public void Hit(List<IItem> items, boolean marioIsBig, HUD hud, SoundEffects sound) { }



    }