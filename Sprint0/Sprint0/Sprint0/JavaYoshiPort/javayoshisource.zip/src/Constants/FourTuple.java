package Constants;
public class FourTuple <A, B, C, D> { 
  public final A a; 
  public final B b;
  public final C c;
  public final D d;
  public FourTuple(A a_init, B b_init, C c_init, D d_init) { 
    a = a_init; 
    b = b_init; 
    c = c_init;
    d = d_init;
  } 
} 