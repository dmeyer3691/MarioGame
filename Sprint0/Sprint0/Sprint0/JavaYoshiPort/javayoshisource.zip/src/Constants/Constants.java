package Constants;
import org.newdawn.slick.Color;

public final class Constants
    {
        //mario state constants
        public final static int blinkFramecount = 5;
        public final static int invinciblityTimeout = 28;
        public final static int hitTimeout = 35;
        public final static int itemTimeout = 60;
        public final static int starTimeout = 500;//could use refining
        //level drawing constants
        public final static int levelHeight = 240;//calibrated via testing
        public final static Color backgroundOneColor = new Color(92, 148, 252);//this color matches the sky color of BackgroundOne.
        public final static int undergroundSectionDepth = -8000;//should be plenty.
        //object behavior constants
        public final static int flagpoleEdge = 3166;//seems fine
        public final static int bottomOfFlagpole = 416;
        public final static int castleDoorPos = 37 + 3232;//39 is the pixels from left side to door center, 3232 is castle left edge in xml.
        public final static int enemyWakeDistance = 800;
        public final static int tileLength = 16;
        public final static int ticksPerFrame = 5;//maybe still a little fast?
        //camera constants
        public final static int cameraBuffer = 450;
        public final static int cameraVelocity = 3; //4 makes the camera too jittery to be pleasant, 2 allows for mario to outrun the camera.
        public final int screenWidth = 800;
        //mario physics constants
        public final static int jumpLimit = 25;
        public final static double velocityDecay = 0.8;
        public final static int marioRunningSpeed = 3;
        public final static int marioWalkingSpeed = 2;
        public final static int marioFallingSpeed = 1;
        public final static int marioJumpingSpeed = 4;
        public final static int marioBounceLimit = 20;
        public final static int marioBounceDisplacement = 2;
        //HUD constants
        public final static int initialTime = 400;
        public final static int coinValue = 200;
        public final static int brokenBrickValue = 50;
        public final static int mushroomValue = 1000;
        public final static int fireflowerValue = 1000;
        public final static int starValue = 1000;
        public final static int oneUpValue = 1000;
        public final static int initialLives = 3;
        public final static int[] enemyKilledPoints = {100, 200, 400, 500, 800, 1000, 2000, 4000, 8000, 10000};
        //level warp constants
        public final static Tuple<Integer,Integer> verticalWarp = new Tuple<Integer,Integer>(-7984,432);
        public final static Tuple<Integer,Integer> horizontalWarp = new Tuple<Integer,Integer>(2624,400);
     

    }
