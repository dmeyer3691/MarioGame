package Constants;
import java.io.IOException;

import org.newdawn.slick.openal.Audio;
import org.newdawn.slick.openal.AudioLoader;
import org.newdawn.slick.util.ResourceLoader;
    public class SoundEffects
    {
        private Audio marioTheme;
        private Audio oneUp;
        private Audio breakBlock;
        private Audio bump;
        private Audio coin;
        private Audio fireball;
        private Audio flagpole;
        private Audio gameOver;
        private Audio kick;
        private Audio pause;
        private Audio pipe;
        private Audio powerup;
        private Audio popup;
        private Audio marioDie;

        public SoundEffects() throws IOException
        {
            marioTheme = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/main-theme-overworld.wav"));
            oneUp =	AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_1-up.wav"));
            breakBlock = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_breakblock.wav"));
            bump = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_bump.wav"));
            coin = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_coin.wav"));
            fireball = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_fireball.wav"));
            flagpole = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_flagpole.wav"));
            gameOver = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_gameover.wav"));
            kick = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_kick.wav"));
            pause = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_pause.wav"));
            pipe = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_pipe.wav"));
            powerup = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_powerup.wav"));
            popup = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_powerup_appears.wav"));
            marioDie = AudioLoader.getAudio
            		("WAV", ResourceLoader.getResourceAsStream("Content/Sounds/smb_mariodie.wav"));
        	
        }

        public void StartTheme()
        {
        	marioTheme.playAsMusic(1.0f, 1.0f, true);
        }

        public void StopTheme()
        {
            marioTheme.stop();
        }

        public void OneUp()
        {
            oneUp.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void FlagPole()
        {
            flagpole.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void Pipe()
        {
            pipe.playAsSoundEffect(1.0f,1.0f,false);
        }


        public void GameOver()
        {
            gameOver.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void Powerup()
        {
            powerup.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void Pause()
        {
            pause.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void Popup()
        {
            popup.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void Coin()
        {
            coin.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void MarioDie()
        {
            marioDie.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void Fireball()
        {
            fireball.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void Bump()
        {
            bump.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void Kick()
        {
            kick.playAsSoundEffect(1.0f,1.0f,false);
        }

        public void BreakBlock()
        {
            breakBlock.playAsSoundEffect(1.0f,1.0f,false);
        }

    }