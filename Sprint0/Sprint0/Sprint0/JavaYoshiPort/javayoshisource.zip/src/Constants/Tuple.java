package Constants;
public class Tuple <A, B> { 
  public final A a; 
  public final B b; 
  public Tuple(A a_init, B b_init) { 
    a = a_init; 
    b = b_init; 
  } 
} 