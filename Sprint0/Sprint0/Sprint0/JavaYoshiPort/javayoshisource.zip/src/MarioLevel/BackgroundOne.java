package MarioLevel;

import Camera.Camera;
import Interfaces.ISprite;
import Constants.Constants;

    class BackgroundOne
    {
        private ISprite BackgroundSprite = new Sprites.BackgroundSprite();
        Camera camera;
        
        public BackgroundOne(Camera cam)
        {
            camera = cam;
        }


        public void Draw()
        {
            if (camera.CameraPos() >= 0)
            {
                camera.Draw(BackgroundSprite, camera.CameraPos(), Constants.levelHeight);
            }
        }

        public void Update()
        {
        }

    }