package MarioLevel;

import java.io.*;
import java.util.LinkedList;
import java.util.List;

import Blocks.*;
import Blocks.Brick.BrickState;
import Camera.Camera;
import Constants.*;
import Enemies.*;
import Interfaces.*;
import Items.*;
import Mario.Mario;

    public class MarioLevelLoader
    {
        /*Note: for the purposes of this level loader I assume that XML tags appear one tag per line. 
         * This is how the levels will be set up in the file, but is a restriction from XML at large.
         */

        static public MarioLevel LoadLevelFromFile(String filename, SoundEffects s) throws IOException
        {
            MarioLevel level = null;
            filename = "Content/" + filename;//TODO
            	BufferedReader stream = new BufferedReader(new FileReader(filename));
                level = LoadLevel(stream, s);
            return level;
        }
        static private MarioLevel LoadLevel(BufferedReader stream, SoundEffects s) throws IOException
        {
            List<IEnemy> enemies = new LinkedList<IEnemy>();
            List<IBlock> blocks = new LinkedList<IBlock>();
            List<IItem> items = new LinkedList<IItem>();
            Mario mario = null;
            Flagpole flagpole = null;
            Camera cam = new Camera();
            HUD hud = new HUD();
            SoundEffects sound = s;

                String tag;

                stream.readLine(); //should be <level>
                while ((tag = stream.readLine()) != null && !tag.equals("</level>"))
                {
                    String[] words = tag.split(" ");
                    Integer xpos = null;
                    Integer ypos = null;
                    boolean isMario = false;
                    if (words[0].equals("<mario")) isMario = true;
                    //because type uniquely specifies things anyways, and type is required for non marios, no need to check for the other possibilities here.
                    String type = "";
                    for (int wordsCount = 1; wordsCount < words.length; wordsCount++)
                    {
                        if (words[wordsCount].length() >= 6)
                        {
                            if(words[wordsCount].substring(0,5).equals("type=")) 
                            {
                                type = words[wordsCount].substring(5).replaceAll("\"","").toLowerCase();                                
                            }
                            else if (words[wordsCount].substring(0, 5).equals("xpos="))
                            {
                                xpos = Integer.valueOf(words[wordsCount].substring(5).replaceAll("\"","").toLowerCase());
                            }
                            else if (words[wordsCount].substring(0, 5).equals("ypos="))
                            {
                                ypos = Integer.valueOf(words[wordsCount].substring(5).replaceAll("\"","").toLowerCase());
                            }
                        }
                    }
                    if ((xpos == null) || (ypos == null)) continue; //if we didn't read a position, we can't place it in the world. (if we didn't read a type, then type = "" and it wont get placed in a list anyways)
                    if (isMario) mario = new Mario(xpos, ypos, cam, sound);
                    else
                    {
                        switch (type.replaceAll("\"",""))
                        {
                            case "goomba":
                                enemies.add(new Goomba(xpos, ypos,cam));
                                break;
                            case "greenkoopa":
                                enemies.add(new GreenKoopa(xpos, ypos,cam));
                                break;
                            case "brick":
                                blocks.add(new Brick(xpos, ypos,cam, BrickState.bempty));
                                break;
                            case "starbrick":
                                blocks.add(new Brick(xpos, ypos, cam, BrickState.bstar));
                                break;
                            case "hitqblock":
                                blocks.add(new Brick(xpos, ypos,cam, BrickState.qempty));
                                break;
                            case "qblock":
                                blocks.add(new Brick(xpos, ypos, cam, BrickState.qcoin));
                                break;
                            case "qitem":
                                blocks.add(new Brick(xpos, ypos, cam, BrickState.qitem));
                                break;
                            case "qlife":
                                blocks.add(new Brick(xpos, ypos, cam, BrickState.qlife));
                                break;
                            case "pipe":
                                blocks.add(new Pipe(xpos, ypos,cam));
                                break;
                            case "pipe2":
                                blocks.add(new Pipe2(xpos, ypos, cam));
                                break;
                            case "vpipe":
                                blocks.add(new VerticalWarpPipe(xpos, ypos, cam));
                                break;
                            case "hpipe":
                                blocks.add(new HorizontalWarpPipe(xpos, ypos, cam));
                                break;
                            case "roughplatform":
                                blocks.add(new RoughPlatform(xpos, ypos,cam));
                                break;
                            case "smoothplatform":
                                blocks.add(new SmoothPlatform(xpos, ypos,cam));
                                break;
                            case "flagpole":
                                flagpole = new Flagpole(xpos, ypos, cam);
                                break;
                            case "castle":
                                blocks.add(new Castle(xpos, ypos, cam));
                                break;
                            case "greenplatform":
                                blocks.add(new GreenRoughPlatform(xpos, ypos, cam));
                                break;
                            case "greenbrick":
                                blocks.add(new GreenBrick(xpos, ypos, cam));
                                break;
                            case "coin":
                                items.add(new Coin(xpos, ypos, cam));
                                break;
                            case "fireflower":
                                items.add(new Fireflower(xpos, ypos, cam));
                                break;
                            case "mushroom":
                                items.add(new Mushroom(xpos, ypos, cam));
                                break;
                            case "oneup":
                                items.add(new Oneup(xpos, ypos, cam));
                                break;
                            case "star":
                                items.add(new Star(xpos, ypos, cam));
                                break;
                            default:
                                break;
                        }
                    }
                }
                cam.Init(mario);
                return new MarioLevel(items,enemies,blocks,mario,cam, hud, sound,flagpole);
        }
    }