package MarioLevel;

import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Interfaces.*;
import Constants.*;

    class UndergroundBackground implements IBlock
    {
        private ISprite BackgroundSprite = new Sprites.BlackRectangleSprite();
        Camera camera;

        public UndergroundBackground(Camera cam)
        {
            camera = cam;
        }


        public void Draw()
        {
            camera.Draw(BackgroundSprite, Constants.undergroundSectionDepth, Constants.levelHeight);
            camera.Draw(BackgroundSprite, Constants.undergroundSectionDepth, 0);

        }

        public void Update()
        {
        }

        public Rectangle GetRectangle()
        {
            return new Rectangle(0, 0, 0, 0);//don't collide
        }

        public void Hit(List<IItem> items, boolean marioIsBig, HUD h,SoundEffects s) { }



    }
