package MarioLevel;
import org.newdawn.slick.Color;
import org.newdawn.slick.Font;

import Constants.*;
import Mario.Mario;
    public class HUD
    {

        private int Score;
        private Integer Time;
        private Integer Coins;
        private Integer Lives;
        private int enemyKilledCount;

        public HUD()
        {
            Lives = Constants.initialLives;
            Score = 0;
            Coins = 0;
            Time = Constants.initialTime;
            enemyKilledCount = 0;
        }

        public void Update(double time, double previous)
        {
            Time = Constants.initialTime - (int) ((time-previous)/1000.0);
        }

        public void Draw(Font font)
        {
            font.drawString(10,10,"MARIO" + addSpaces(4) + "COINS" + addSpaces(4) + "WORLD" + addSpaces(5) + "TIME" + addSpaces(4) + "LIVES", Color.white);
            font.drawString(10,25, formattedScore() + addSpaces(4) + formattedCoins() + addSpaces(7) + "1-1" + addSpaces(6) + Time.toString() + addSpaces(5) + formattedLives(), Color.white);
        }

        public void enemyKill(Mario mario)
        {
            if (mario.isInKillSequence())
            {
                enemyKilledCount++;
            }
            else
            {
                enemyKilledCount = 0;
            }
            Score += Constants.enemyKilledPoints[enemyKilledCount];
        }

        public void addCoin()
        {
            Coins++;
        }

        public void extraLife()
        {
            Lives++;
        }

        public void lifeLost()
        {
            if (Lives == 0)
            {
                //death screen
            }
            else if (Lives > 0)
            {
                Lives--;
                //restart screen
            }
        }

        public void increaseScore(int score)
        {
            Score += score;
        }

        private String addSpaces(int spaces)
        {
            String text = "";
            for (int i = 0; i < spaces; i++) text = text + " ";
            return text;
        }

        private String formattedScore()
        {
            int gameScore = Score;
            String text = "";
            for (int i = 0; i < 6; i++)
            {
                text = (gameScore % 10) + text;
                gameScore /= 10;
            }
            return text;
        }

        private String formattedCoins()
        {
            String text = "";
            if (Coins < 10)
            {
                text = "0" + Coins.toString();
            }
            else
            {
                text = Coins.toString();
            }
            return text;
        }

        private String formattedLives()
        {
            String text = "";
            if (Lives < 10)
            {
                text = "0" + Lives.toString();
            }
            else if (Lives > 99)
            {
                text = "99";
                Lives = 99;
            }
            else
            {
                text = Lives.toString();
            }
            return text;
        }
    }