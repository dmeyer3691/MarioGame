package MarioLevel;

import java.util.LinkedList;
import java.util.List;

import Camera.Camera;
import Constants.*;
import Interfaces.*;
import Mario.*;


    public class MarioLevel
    {
        private List<IItem> itemList;
        private List<IEnemy> enemyList;
        private List<IBlock> blockList;
        public Mario mario;
        private Camera camera;
        private BackgroundOne background;
        private UndergroundBackground undergroundBackground;
        public HUD hud;
        public SoundEffects sound;
        private Blocks.Flagpole flagpole;
        private boolean onFlagpole;
        private FlagMario flagMario;
        public MarioLevel(List<IItem> i, List<IEnemy> e, List<IBlock> b, Mario m, Camera c, HUD h, SoundEffects s, Blocks.Flagpole f)
        {
            itemList = i;
            enemyList = e;
            blockList = b;
            mario = m;
            camera = c;
            background = new BackgroundOne(c);
            undergroundBackground = new UndergroundBackground(c);
            hud = h;
            sound = s;
            sound.StartTheme();
            flagpole = f;
            onFlagpole = false;
        }

        public void Draw()
        {
            if (mario.getXPosition() >= 0)
            {
                background.Draw();
            }
            else
            {
                undergroundBackground.Draw();
            }
            // draw game objects
            for (IEnemy enemy : enemyList)
            {
                enemy.Draw();
            }
            for(IItem item : itemList)
            {
                item.Draw();
            }
            for(IBlock block : blockList)
            {
                block.Draw();
            }
            flagpole.Draw();
            if (onFlagpole) flagMario.Draw();
            else mario.Draw();
        }

        public void Update()
        {
            camera.Update();
            background.Update();

            // update game objects
            if (!mario.IsDead() && !mario.IsHit() && !mario.GettingItem())
            {
                LinkedList<IItem> doomedItems = new LinkedList<IItem>();
                for (IItem item : itemList)
                {
                    item.Update(blockList);
                    if (item.DestroyItem())
                    {
                        doomedItems.add(item);
                    }
                }
                while (doomedItems.size() > 0)
                {
                    IItem items = doomedItems.remove();
                    itemList.remove(items);
                }

                for (IEnemy enemy : enemyList)
                {
                    enemy.Update(blockList, enemyList);
                }
                for (IBlock block : blockList)
                {
                    block.Update();
                }               
            }
            if (!mario.IsDead())
            {
                mario.BlockCollisionTest(hud, blockList, itemList);
                mario.ItemCollisionTest(hud, itemList);
                mario.EnemyCollisionTest(hud, enemyList);
            }
            if ((mario.getXPosition() >= Constants.flagpoleEdge) && onFlagpole == false)
            {
                sound.FlagPole();
                onFlagpole = true;
                FlagMario.marioPowerupState m;
                if (!mario.IsLarge()) m = FlagMario.marioPowerupState.small;
                else if (mario.HasFire()) m = FlagMario.marioPowerupState.fire;
                else m = FlagMario.marioPowerupState.big;
                flagMario = new FlagMario(mario.getXPosition(),mario.getYPosition(),camera,m);
            }
            if (onFlagpole) flagMario.Update();
            else mario.Update();
        }

    }