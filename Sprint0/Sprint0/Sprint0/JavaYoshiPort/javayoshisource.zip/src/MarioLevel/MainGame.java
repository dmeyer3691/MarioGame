package MarioLevel;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;

import Constants.*;
import Controllers.KeyboardController;
import Interfaces.IController;

public class MainGame extends BasicGame {
	public MainGame(String title) {
		super(title);
	}
	private static AppGameContainer appgc;
	private static IController keyboardController;
	private static MarioLevel level;
	private static SoundEffects sound;
    private static double totalTime = 0;
    private static double previousTime = 0;
    private boolean paused = false;
	
    @Override
    public void init(GameContainer gc) {
		try {
			sound = new SoundEffects();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Reset();
        keyboardController = new KeyboardController();
        try {
			Sprites.SpriteFactory.loadContent();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		gc.getGraphics().setBackground(Constants.backgroundOneColor);
		previousTime = gc.getTime();
    }
    @Override
    public void render(GameContainer gc, Graphics g) {
    	level.Draw();
    	level.hud.Draw(appgc.getDefaultFont());
    }

	public void Pause() {
        paused = true;
        sound.Pause();
	}
	
    public void UnPause()
    {
        paused = false;
        sound.Pause();
    }
	
    
    public static void Reset()
    {
        previousTime = totalTime;
        totalTime = 0;
        try {
			level = MarioLevelLoader.LoadLevelFromFile("1-1.xml", sound);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
        
    @Override
    public void update(GameContainer gc, int i) {
    	keyboardController.Update(this, level.mario);
    	 if (!paused)
         {
             totalTime = gc.getTime();
    		 
             level.Update();
             level.hud.Update(totalTime, previousTime);
             if (level.mario.getYPosition() > gc.getScreenHeight())
             {
                 Reset();
             }
         }
    }
        
    public void Exit() {
    	appgc.exit();
    }
    
	public static void main(String[] args) {
		try
		{
			appgc = new AppGameContainer(new MainGame("Team Yoshi Java Port"));
			appgc.setDisplayMode(800, 480, false);
	        appgc.setVSync(true);
	        appgc.setShowFPS(false);
			appgc.start();
		}
		catch (SlickException ex)
		{
			Logger.getLogger(MainGame.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
