package Mario;
import java.util.List;

import org.lwjgl.util.Rectangle;

import Camera.Camera;
import Collisions.*;
import Constants.*;
import Interfaces.*;
import MarioLevel.HUD;

    public class Mario
    {
        private int xPosition;
        private int yPosition;
        private MarioState State;
        private MarioItemCollision itemCollision;
        private MarioEnemyCollision enemyCollision;
        private MarioBlockCollision blockCollision;
        private Camera camera;
        private MarioPhysics Physics;
        private SoundEffects sound;
        private boolean enemyKillSequence;
        private boolean enemyKilled;


        // constructor
        public Mario(int x, int y, Camera cam, SoundEffects s)
        {
            camera = cam;
            xPosition = x;
            yPosition = y;
            State = new MarioState(this, cam);
            Physics = new MarioPhysics(this, State);
            itemCollision = new MarioItemCollision(this);
            enemyCollision = new MarioEnemyCollision(this);
            blockCollision = new MarioBlockCollision(this);
            sound = s;
            enemyKillSequence = false;
            enemyKilled = false;
        }


        public void Update()
        {
            State.Update();
            if (!GettingItem()) Physics.Update();
            //if mario is beyond the camera horizon, clip
            if (xPosition < camera.CameraPos()) xPosition = camera.CameraPos();
            if (Physics.getHitGround()) enemyKillSequence = false;

        }

        public void Draw()
        {
            State.Draw(xPosition, yPosition);
        }

        public Rectangle GetRectangle()
        {
            return new Rectangle(xPosition, yPosition, State.GetWidth(), State.GetHeight());
        }

        public boolean killedEnemy()
        {
            return enemyKilled;
        }

        public boolean isInKillSequence()
        {
            return enemyKillSequence;
        }

        public int getXPosition()
        {
            return xPosition;
        }

        public int getYPosition()
        {
            return yPosition;
        }

        public void setXPosition(int x)
        {
            xPosition = x;
        }

        public void setYPosition(int y)
        {
            yPosition = y;
        }

        //Collision Tests
        public void BlockCollisionTest(HUD hud, List<IBlock> blocks, List<IItem> items)
        {
            FourTuple<Integer, Integer, Boolean, Boolean> result = blockCollision.BlockCollisionTest(sound, hud, blocks, xPosition, yPosition, items, camera);
            xPosition = result.a;
            yPosition = result.b;
            Physics.setHitCeiling(result.c);
            Physics.setHitGround(result.d);
        }

        public void ItemCollisionTest(HUD hud, List<IItem> items)
        {
            itemCollision.ItemCollisionTest(sound, hud, items);
        }

        public void EnemyCollisionTest(HUD hud, List<IEnemy> enemies)
        {
            Tuple<Integer, Boolean> result = enemyCollision.EnemyCollisionTest(this, hud, enemies, xPosition, sound);
            xPosition = result.a;
            enemyKilled = result.b;
            if (enemyKilled)
            {
                Physics.resetBounceCounter();
                enemyKillSequence = true;
            }
        }

        // Extending MarioSprite methods
        public void Crouch()
        {
            State.Crouch();
            Physics.Crouch();
        }

        public void Stand()
        {
            Physics.Stand();
        }

        public void Jump()
        {
            State.Jump();
            Physics.Jump();
        }

        public void Walk()
        {
            Physics.setRunning(false);
            State.Walk();
        }

        public void Dead()
        {
            sound.StopTheme();
            sound.MarioDie();
            State.Dead();
            Physics.resetBounceCounter();
        }

        public void Hit()
        {
            State.Hit();
        }

        public boolean Invincible()
        {
            return State.IsInvincible();
        }

        public void Mushroom() 
        {
            State.Mushroom();
        }

        public void Fireflower()
        {
            State.Fireflower();
        }

        public void Left()
        {
            State.Left();
            Physics.Left();
            Walk();
        }

        public void Right()
        {
            State.Right();
            Physics.Right();
            Walk();
        }

        public void Run()
        {
            Physics.setRunning(true);
        }

        public void Fireball()
        {
        	//never implemented properly in XNA
        }

        public void Star()
        {
            State.Star();
        }

        public boolean IsDead()
        {
            return State.IsDead();
        }
        public boolean IsHit()
        {
            return State.IsHit();
        }
        public boolean GettingItem()
        {
            return State.GettingItem();
        }
        public boolean IsLarge()
        {
            return State.IsLarge();
        }
        public boolean IsCrouching()
        {
            return State.IsCrouching();
        }
        public boolean HasFire()
        {
            return State.HasFire();
        }
    }
