package Controllers;

import java.util.HashMap;
import java.util.Map;

import org.lwjgl.input.Keyboard;

import Commands.*;
import Interfaces.IController;
import Mario.Mario;
import MarioLevel.MainGame;



    public class KeyboardController implements IController
    {

        private enum PossibleCommands { left, right, crouch, stand, run, jump, reset, quit, pause, unpause, fireball };
        private HashMap<Integer, PossibleCommands> keymap;
        private boolean paused = false;

        public boolean isPaused()
        {
            return paused;
        }

        public KeyboardController()
        {
            keymap = new HashMap<Integer, PossibleCommands>();
            keymap.put(Keyboard.KEY_A, PossibleCommands.left);
            keymap.put(Keyboard.KEY_LEFT, PossibleCommands.left);
            keymap.put(Keyboard.KEY_D, PossibleCommands.right);
            keymap.put(Keyboard.KEY_RIGHT, PossibleCommands.right);
            keymap.put(Keyboard.KEY_S, PossibleCommands.crouch);
            keymap.put(Keyboard.KEY_DOWN, PossibleCommands.crouch);
            keymap.put(Keyboard.KEY_Z, PossibleCommands.run);
            keymap.put(Keyboard.KEY_L, PossibleCommands.run);
            keymap.put(Keyboard.KEY_X, PossibleCommands.jump);
            keymap.put(Keyboard.KEY_K, PossibleCommands.jump);
            keymap.put(Keyboard.KEY_R, PossibleCommands.reset);
            keymap.put(Keyboard.KEY_Q, PossibleCommands.quit);
            keymap.put(Keyboard.KEY_P, PossibleCommands.pause);
            keymap.put(Keyboard.KEY_U, PossibleCommands.unpause);
            keymap.put(Keyboard.KEY_E, PossibleCommands.fireball);
        }

        private boolean marioCanMove(Mario mario)
        {
            if (mario.IsDead()) return false;
            else if (mario.GettingItem()) return false;
            else return true;
        }

        public void Update(MainGame game, Mario mario)
        {
            boolean aKeyIsPressed = false;
            for(Map.Entry<Integer,PossibleCommands> key : keymap.entrySet())
            {
                if (Keyboard.isKeyDown(key.getKey()))
                {
                    aKeyIsPressed = true;
                    //let these in even if mario is dead/hit
                    switch (key.getValue())
                    {
                        case quit:
                            game.Exit();
                            break;
                        case reset:
						MainGame.Reset();
                            break;
                        case pause:
                            game.Pause();
                            paused = true;
                            break;
                        case unpause:
                            game.UnPause();
                            paused = false;
                            break;
					default:
						break;
                    }
                    //and these require him to be not dead/hit
                    if (marioCanMove(mario) && !paused)
                    {
                        switch (key.getValue())
                        {
                            case left:
                                new MarioLeftCommand(mario).Execute();
                                break;
                            case right:
                                new MarioRightCommand(mario).Execute();
                                break;
                            case run:
                                new MarioRunCommand(mario).Execute();
                                break;
                            case jump:
                                new MarioJumpCommand(mario).Execute();
                                break;
                            case crouch:
                                new MarioCrouchCommand(mario).Execute();
                                break;
                            case fireball:
                            	//never implemented in XNA
                                break;
						default:
							break;
                        }
                    }
                }
            }
            if (!aKeyIsPressed && marioCanMove(mario)) new MarioStandCommand(mario).Execute();
        }
    }