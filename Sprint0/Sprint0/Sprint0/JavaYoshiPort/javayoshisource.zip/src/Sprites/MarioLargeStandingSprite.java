package Sprites;

import org.newdawn.slick.Image;

import Interfaces.ISprite;

    public class MarioLargeStandingSprite implements ISprite
    {
        private static Image frame;
        public void Update()
        {
            //static nothing to do
        }
        public void Draw(int x, int y, SpriteEffects facing)
        {
        	if(facing == SpriteEffects.NONE) {
                frame.draw(x,y);
            	} else {
            		frame.getFlippedCopy(true, false).draw(x,y);
            	}        }

        public MarioLargeStandingSprite()
        {
            //nothing to do here
        }

        static public void Init(Image f)
        {
                frame = f;
        }
        public int GetWidth()
        {
            return frame.getWidth();
        }

        public int GetHeight()
        {
            return frame.getHeight();
        }
    }