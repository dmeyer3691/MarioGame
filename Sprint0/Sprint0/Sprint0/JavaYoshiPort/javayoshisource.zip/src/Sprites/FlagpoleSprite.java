package Sprites;

import org.newdawn.slick.Image;

import Interfaces.ISprite;

    public class FlagpoleSprite implements ISprite
    {
        private static Image frame;
        public void Update()
        {
            //static nothing to do
        }
        public void Draw(int x, int y, SpriteEffects facing)
        {
            frame.draw(x,y);
        }

        public FlagpoleSprite()
        {
            //nothing to do here
        }

        static public void Init(Image f)
        {
                frame = f;
        }
        public int GetWidth()
        {
            return frame.getWidth();
        }

        public int GetHeight()
        {
            return frame.getHeight();
        }
    }