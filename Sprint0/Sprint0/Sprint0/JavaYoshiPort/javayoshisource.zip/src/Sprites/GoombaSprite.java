package Sprites;

import java.util.List;

import Interfaces.ISprite;
import Constants.*;
import org.newdawn.slick.Image;

    public class GoombaSprite implements ISprite
    {
        static List<Image> frames;
        private int currentFrame;
        private int currentTick;

        public void Update()
        {
            currentTick++;
            if (currentTick == Constants.ticksPerFrame)
            {
                currentTick = 0;
                currentFrame++;
                if (currentFrame >= frames.size()) currentFrame = 0;
            }

        }
        public void Draw(int x, int y, SpriteEffects facing)
        {
        	frames.get(currentFrame).draw(x,y);
        }
        
        public GoombaSprite()
        {
            currentFrame = 0;
            currentTick = 0;
        }

        public int GetWidth()
        {
            return frames.get(currentFrame).getWidth();
        }

        public int GetHeight()
        {
            return frames.get(currentFrame).getHeight();
        }

        static public void Init(List<Image> f)
        {
                frames = f;
        }
    }