package Sprites;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.LinkedList;

import javax.imageio.ImageIO;

import org.newdawn.slick.Image;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.util.BufferedImageUtil;
    public class SpriteFactory
    {

        public static MarioSmallWalkingSprite MarioSmallWalking;
        public static MarioLargeWalkingSprite MarioLargeWalking;
        public static MarioFireWalkingSprite MarioFireWalking;
        /* Code adapted from linked page to solve problem that asker had on linked page.
         * http://stackoverflow.com/questions/23610295/slick-pngdecoder-error-java-lang-unsupportedoperationexception-unsupported-fo
         */
        private static Image load(String path) throws Exception
        {
            BufferedImage bufferedImage = ImageIO.read(new File(path));
            Texture texture = BufferedImageUtil.getTexture("", bufferedImage);
            Image image = new Image(texture.getImageWidth(), texture.getImageHeight());
            image.setTexture(texture); 
            return image;
        }
        
        public static void loadContent() throws Exception
        //that's a loading exception, so it happening means there's a problem with the initial load that can't be recovered from
        {
            LoadMarioContent();
            LoadEnemyContent();
            LoadBlockContent();
            LoadItemContent();

            // Background Sprite
            BackgroundSprite.Init(load("Content/Sprites/background.png"));
            // Underground Background Sprite
            BlackRectangleSprite.Init(load("Content/Sprites/blackrectangle.png"));
        }

        private static void LoadMarioContent() throws Exception
        {
            // Mario Sprites
            MarioSmallStandingSprite.Init(load("Content/Sprites/Mario/small-standing-mario.png"));
            MarioLargeStandingSprite.Init(load("Content/Sprites/Mario/large-standing-mario.png"));
            MarioFireStandingSprite.Init(load("Content/Sprites/Mario/fire-standing-mario.png"));
            MarioSmallJumpingSprite.Init(load("Content/Sprites/Mario/small-jumping-mario.png"));
            MarioLargeJumpingSprite.Init(load("Content/Sprites/Mario/large-jumping-mario.png"));
            MarioFireJumpingSprite.Init(load("Content/Sprites/Mario/fire-jumping-mario.png"));
            MarioSmallSlidingSprite.Init(load("Content/Sprites/Mario/small-sliding-mario.png"));
            MarioLargeSlidingSprite.Init(load("Content/Sprites/Mario/large-sliding-mario.png"));
            MarioFireSlidingSprite.Init(load("Content/Sprites/Mario/fire-sliding-mario.png"));

            LinkedList<Image> smallWalkingTexture = new LinkedList<Image>();
            for (int i = 1; i < 4; i++) {
            	smallWalkingTexture.add(load("Content/Sprites/Mario/small-walking-mario-"+ i + ".png"));
            }            
            MarioSmallWalking = new MarioSmallWalkingSprite(smallWalkingTexture);
            
            LinkedList<Image> largeWalkingTexture = new LinkedList<Image>();
            for (int i = 1; i < 4; i++) {
            	largeWalkingTexture.add(load("Content/Sprites/Mario/large-walking-mario-"+ i + ".png"));
            }
            MarioLargeWalking = new MarioLargeWalkingSprite( largeWalkingTexture);
            
            LinkedList<Image> fireWalkingTexture = new LinkedList<Image>();
            for (int i = 1; i < 4; i++){
            	fireWalkingTexture.add(load("Content/Sprites/Mario/fire-walking-mario-" + i + ".png"));
            }
            MarioFireWalking = new MarioFireWalkingSprite( fireWalkingTexture);
            
            MarioLargeCrouchingSprite.Init(load("Content/Sprites/Mario/large-crouching-mario.png"));
            MarioFireCrouchingSprite.Init(load("Content/Sprites/Mario/fire-crouching-mario.png"));
            MarioDeadSprite.Init(load("Content/Sprites/Mario/dead-mario.png"));
        }

        private static void LoadEnemyContent() throws Exception
        {
            // Enemies Sprites
            LinkedList<Image> goombaTexture = new LinkedList<Image>();
            for (int i = 1; i < 3; i++) goombaTexture.add(load("Content/Sprites/enemies/goomba-"+ i + ".png"));
            GoombaSprite.Init( goombaTexture);
            
            LinkedList<Image> greenTurtleTexture = new LinkedList<Image>();
            for (int i = 1; i < 3; i++) greenTurtleTexture.add(load("Content/Sprites/enemies/green-turtle-" + i + ".png"));
            GreenTurtleSprite.Init( greenTurtleTexture);
            
        }

        private static void LoadBlockContent() throws Exception
        {
            // Blocks Sprites
            FlagpoleSprite.Init( load("Content/Sprites/blocks/flagpole.png"));
            CastleSprite.Init( load("Content/Sprites/blocks/castle.png"));
            HorizontalPipeSprite.Init( load("Content/Sprites/blocks/horizontal-pipe.png"));
            HitQBlockSprite.Init( load("Content/Sprites/blocks/hit-question-block.png"));
            QBlockSprite.Init( load("Content/Sprites/blocks/question-block.png"));
            TopBrickSprite.Init( load("Content/Sprites/blocks/top-border-brick.png"));
            BrickSprite.Init( load("Content/Sprites/blocks/lower-brick.png"));
            PipeSprite.Init( load("Content/Sprites/blocks/pipe.png"));
            Pipe2Sprite.Init( load("Content/Sprites/blocks/pipe2.png"));
            RoughPlatformSprite.Init( load("Content/Sprites/blocks/rough-platform.png"));
            SmoothPlatformSprite.Init( load("Content/Sprites/blocks/smooth-platform.png"));
        }

        private static void LoadItemContent() throws Exception
        {
            // Items Sprites
            CoinSprite.Init( load("Content/Sprites/items/coin.png"));
            FireflowerSprite.Init( load("Content/Sprites/items/fireflower.png"));
            LinkedList<Image> oneUpTexture = new LinkedList<Image>();
            for (int i = 1; i < 3; i++) oneUpTexture.add(load("Content/Sprites/items/life-up-" + i + ".png"));
            OneUpSprite.Init( oneUpTexture);
            LinkedList<Image> mushroomTexture = new LinkedList<Image>();
            for (int i = 1; i < 3; i++) mushroomTexture.add(load("Content/Sprites/items/mushroom-" + i + ".png"));
            MushroomSprite.Init( mushroomTexture);
            StarSprite.Init( load("Content/Sprites/items/star.png"));
        }
    }
