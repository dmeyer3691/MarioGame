package Commands;

import Interfaces.ICommand;
import Mario.Mario;


    public class MarioRightCommand implements ICommand
    {

        Mario mario;

        public MarioRightCommand(Mario myMario)
        {
            mario = myMario;
        }

        public void Execute()
        {
            mario.Right();
        }
    }