package Commands;

import Interfaces.ICommand;
import Mario.Mario;


    public class MarioStandCommand implements ICommand
    {
        Mario mario;

        public MarioStandCommand(Mario myMario)
        {
            mario = myMario;
        }

        public void Execute()
        {
            mario.Stand();
        }
    }