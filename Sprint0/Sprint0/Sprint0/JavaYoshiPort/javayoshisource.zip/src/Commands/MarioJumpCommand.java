package Commands;

import Interfaces.ICommand;
import Mario.Mario;


    public class MarioJumpCommand implements ICommand
    {

        Mario mario;

        public MarioJumpCommand(Mario myMario)
        {
            mario = myMario;
        }

        public void Execute()
        {
            mario.Jump();
        }
    }