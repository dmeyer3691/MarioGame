package Commands;

import Interfaces.ICommand;
import Mario.Mario;

public class MarioDeadCommand implements ICommand
{
    Mario mario;

    public MarioDeadCommand(Mario myMario)
    {
        mario = myMario;
    }

    public void Execute()
    {
        mario.Dead();
    }
}
