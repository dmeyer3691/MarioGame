package Commands;

import Interfaces.ICommand;
import Mario.Mario;


    public class MarioRunCommand implements ICommand
    {

        Mario mario;

        public MarioRunCommand(Mario myMario)
        {
            mario = myMario;
        }

        public void Execute()
        {
            mario.Run();
        }
    }