package Commands;
import Interfaces.ICommand;
import Mario.Mario;

    public class MarioCrouchCommand implements ICommand
    {

        Mario mario;

        public MarioCrouchCommand(Mario myMario)
        {
            mario = myMario;
        }

        public void Execute()
        {
            mario.Crouch();
        }
    }
