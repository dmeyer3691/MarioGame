package Commands;

import Interfaces.ICommand;
import Mario.Mario;


    public class MarioLeftCommand implements ICommand
    {

        Mario mario;

        public MarioLeftCommand(Mario myMario)
        {
            mario = myMario;
        }

        public void Execute()
        {
            mario.Left();
        }
    }